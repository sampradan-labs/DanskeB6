﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBL
{
    // interface => Only declarations, NO LOGIC
   public interface IEngine
    {
        public int Rating { get; set; }
        public void Works();
    }

    public class SuzukiEngine : IEngine
    {
        public double Cost { get; set; }
        public int Rating { get; set; }

        public void Works()
        {
            Console.WriteLine("Works efficiently giving an average of 10km / litre");
        }
    }
}
