﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBL
{
    //abstract | interface => incomplete | Only declarations
    public abstract class Car {
        public string Name { get; set; }
        public string Color { get; set; }
        public SuzukiEngine CarEngine { get; set; }

        public abstract void Buy();

        public virtual double GetEngineCost()
        {
            return this.CarEngine.Cost;
        }
    }

    public class MarutiCar : Car
    {
        public MarutiCar(SuzukiEngine engine)
        {
            this.CarEngine = engine;
        }

        public string Type { get; set; }

        public override double GetEngineCost()
        {
            return this.CarEngine.Cost + new Random().NextDouble();
        }

        public override void Buy()
        {
            switch (this.Type)
            {
                case "Sedan":
                    Console.WriteLine("Total cost is 6L + GST");
                    break;
                case "HatchBack":
                    Console.WriteLine("Total cost is 3L + GST");
                    break;
                case "SUV":
                    Console.WriteLine("Total cost is 12L + GST");
                    break;

                default:
                    Console.WriteLine("Entered Type is invalid");
                    break;
            }
        }
    }
}
