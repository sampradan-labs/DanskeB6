﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FirstApi.Models
{
    public class Person
    {
        //only properties here
        [Key]
        [Required(ErrorMessage ="Aadhar is mandatory")]
        public string Aadhar { get; set; }

        [Range(18,99,ErrorMessage ="Age should be between 18-99yrs")]
        public int Age { get; set; }

        [StringLength(20, ErrorMessage ="Name can be upto 20 characters long")]
        //[RegularExpression("d(5)",ErrorMessage ="Pattern mismatch")]
        //[EmailAddress(ErrorMessage ="Email is invalid")]
        //[Compare(nameof(Aadhar),ErrorMessage ="Aadhar & Name should match")]
        public string Name { get; set; }
    }

    public class PersonRepository
    {
        private static List<Person> _people = new List<Person>();
        //only methods for Person class
        public List<Person> GetAll() {
            if (_people.Count == 0)
            {
                _people.Add(new Person() {Name="Eena", Aadhar="12345", Age=25 });
                _people.Add(new Person() { Name = "Meena", Aadhar = "12346", Age = 25 });
                _people.Add(new Person() { Name = "Deeka", Aadhar = "12347", Age = 25 });
            }
            return _people;
        }
        public bool AddPerson(Person p) {
            _people.Add(p);
            return true;
        }
        public bool UpdatePerson(string aadhar, Person updated) {
            foreach (var singlePerson in _people)
            {
                if (singlePerson.Aadhar == aadhar)
                {
                    singlePerson.Age = updated.Age;
                    singlePerson.Name = updated.Name;
                    return true;
                }
            }
            return false;
        }

        public bool DeletePerson(string aadhar) {
            foreach (var singlePerson in _people)
            {
                if (singlePerson.Aadhar == aadhar)
                {
                    _people.Remove(singlePerson);
                    return true;
                }
            }
            return false;
        }
    }
}
