﻿using FirstApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        PersonRepository dataContext = new PersonRepository();

        [HttpGet("/get")]
        public IActionResult GetPeople()
        {
            return Ok(dataContext.GetAll());
        }

        
        [HttpPost("/add")]
        public IActionResult AddPerson([FromBody] Person p)
        {
            if (ModelState.IsValid)
            {
                bool result = dataContext.AddPerson(p);
                if (result == true)
                {
                    return Created("/add", $"Person {p.Name} is added to the DB");
                }
            }           

            return Unauthorized($"Error adding Person {p.Name}");            
        }

        [HttpPut("/update/{aadhar}")]
        public string UpdatePerson(string aadhar, [FromBody] Person p)
        {
            bool result =dataContext.UpdatePerson(aadhar, p);
            if (result == true)
            {
                return $"Person {p.Name} is updated in the DB";
            }

            return $"Error updating Person {p.Name}";
        }

        [HttpDelete("/delete/{aadhar}")]
        public string DeletePerson(string aadhar)
        {
            bool result = dataContext.DeletePerson(aadhar);
            if (result == true)
            {
                return $"Person is deleted from the DB";
            }

            return $"Error deleting Person";
        }
    }
}
