﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SimpleController : ControllerBase
    {
        [HttpGet("/welcome")]
        public string Welcome()
        {
            return "Welcome to Web Methods using Web API";
        }

        [HttpGet("/names")]
        public List<string> GetNames()
        {
            List<string> names = new List<string> { "Eena", "Meena", "Deeka"};
            return names;
        }

        [HttpGet("/name/{panId}")]
        public string GetName(string panId)
        {
            return $"Sreevalli has a pan id: {panId}";
        }
    }
}
