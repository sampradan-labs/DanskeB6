﻿using CarBL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarController : ControllerBase
    {
        MarutiCar carContext = new MarutiCar(new SuzukiEngine() { Cost = 300000, Rating = 5 });

        [HttpGet("/buy/{name}/{type}/{color}")]
        public MarutiCar Buy(string name, string type, string color)
        {
            carContext.Name = name;
            carContext.Color = color;
            carContext.Type = type;

            carContext.Buy();
            return carContext;
        }
    }
}
