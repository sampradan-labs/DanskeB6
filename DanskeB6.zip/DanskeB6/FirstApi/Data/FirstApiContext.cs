﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using FirstApi.Models;

namespace FirstApi.Data
{
    public class FirstApiContext : DbContext
    {
        public FirstApiContext (DbContextOptions<FirstApiContext> options)
            : base(options)
        {
        }

        public DbSet<FirstApi.Models.Person> Person { get; set; }
    }
}
