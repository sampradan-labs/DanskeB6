﻿using System;
using CarBL;

namespace CarUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create the car object
            MarutiCar myCar = new MarutiCar(new SuzukiEngine() { Cost = 200000d, Rating=4 });
            myCar.Name = "Swift Desire Z Series";
            myCar.Color = "Silver";
            myCar.Type = "Sedan";

            //Call buy
            myCar.Buy();
            myCar.CarEngine.Works();
            Console.WriteLine($"Engine cost: {myCar.CarEngine.Cost}");

            //display details
            Console.WriteLine($"Our new family member {myCar.Name} which is {myCar.Color} and its a {myCar.Type}");

            //
            SuzukiEngine eng = new SuzukiEngine();
            eng.Works();

            IEngine superEngine = new SuzukiEngine();
            superEngine.Works();

            ////////////Another Car
            ///MANTRA: Base = new Derived()
            ///Above way of declaration will invoke all derived class methods
            ///
            SuzukiEngine suz = new SuzukiEngine();
            Car superCar = new MarutiCar(suz) { Type="SUV"};
            superCar.Name = "Super Car";
            superCar.Color = "Gold";            
            superCar.Buy();
        }
    }
}
