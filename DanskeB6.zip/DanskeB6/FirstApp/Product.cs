﻿using System;

namespace FirstApp
{
    class MyProduct
    {
        static void GetMyProduct(string[] args)
        {
            Console.WriteLine("Hello C# in VsCode!");
        }
    }
}
