﻿using System;

namespace FirstApp
{
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello C# in VsCode!");
            
        }
    }

    class SpecialProgram { }

    class SuperProgram { }
}
