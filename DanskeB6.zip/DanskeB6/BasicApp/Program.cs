﻿using System;
using System.Collections.Generic;
using BasicApp1;

namespace BasicApp
{
    class SampleClass
    {

    }

    class Program
    {

        static void Main(string[] args)
        {
            //ReadWrite();
            //WorkingWithDatatypes();
            //UseConditions();
            //TweakingTypes();
            //UsingSwitch();
            //UsingCollections();

            //WorkWithClass();
            //WorkWithStaticClass();
            //CallMultipleConstructors();
            //CallBaseClassContructor();
            //FunWithProtected();
            //CallMultiLevelInheritance();
            TestOverloading();
            GC.Collect();
        }

        private static void TestOverloading()
        {
            OverLoadedClass objOverloaded = new OverLoadedClass();
            objOverloaded.DoSomething();
            objOverloaded.DoSomething("Coding");
            objOverloaded.DoSomething(true);    //second param = task A
            objOverloaded.DoSomething(true, "Testing"); //second param = Testing
            objOverloaded.DoSomething("Attending C# training",90,null);
        }

        private static void CallMultiLevelInheritance()
        {
            A objA = new A();
            B objB = new B();
            C objC = new C();

            //Having fun
            Console.WriteLine($"objA has properties: {nameof(objA.PropA)}");
            Console.WriteLine($"objB has properties: {nameof(objB.PropA)}, {nameof(objB.PropB)}");
            Console.WriteLine($"objC has properties of A,B,C: {nameof(objC.PropA)}, {nameof(objC.PropB)}, {objC.PropA} ");

            //AccessAll()
            objC.AccessAll();
        }

        private static void FunWithProtected()
        {
            //create child class object
            Child objChild = new Child("Neeta");
            //objChild.SecretGift();    //cannot be accessed

            GrandChild objGrandChild = new GrandChild("Sona");
            //objGrandChild.SecretGift();    //cannot be accessed
            objGrandChild.ShareParentGift();    //accessed by exposing a public function
        }

        private static void CallBaseClassContructor()
        {
            GrandChild objGrandChild = new GrandChild("Sona");
            Console.WriteLine($"Grandchild name: {objGrandChild.Name}");
        }

        private static void CallMultipleConstructors()
        {
            Parent objParent = new Parent(12345, "Sunita Nagarjun");
            Console.WriteLine($"Aadhar: {objParent.Aadhar}, Name: {objParent.Name}");
        }

        private static void WorkWithStaticClass()
        {
            Utilities.Value = "A static value";
            Utilities.Print($"The value of static property is:" +
                $"{Utilities.Value}");
        }

        private static void WorkWithClass()
        {
            //Construct the real object from template
            Product HeadPhone = new Product(5000d);
            HeadPhone.Name = "Head Phones";
            HeadPhone.ProductId = 1011;
            Console.WriteLine($"Purchased the product {HeadPhone.Name}" +
                   $" with Product Id {HeadPhone.ProductId} " +
                   $"at INR {HeadPhone.Cost}");

            ///// Work with Store
            ///
            Store myStore = new Store();
            myStore.Name = "MY STORE";
            myStore.AddProduct(HeadPhone);
            myStore.AddProduct(new Product(15000, 12345) { Name = "MI Phone" });

            List<Product> allProducts = myStore.GetProducts();
            foreach (var product in allProducts)
            {
                Console.WriteLine($"{product.Name} costs INR {product.Cost}");
            }

            
            int num = 10;
            PassByValue(num);
            Console.WriteLine(num);

            PassByRef(ref HeadPhone);
            Console.WriteLine($"Original headphone object: {HeadPhone.Name}");
        }

        private static void PassByRef(ref Product p)
        {
            p.Name = "Changed Name";
            Console.WriteLine(p.Name);
        }

        private static void PassByValue(int val)
        {
            val = 100;
            Console.WriteLine(val);
        }

        private static void UsingCollections()
        {
            string[] names = { "Eena", "Meena", "Deeka" };
            int[] ints = new int[3] { 1, 2, 3 };

            names[0] = "Teena";  //change the value at position 0

            //Expandable array a.k.a collection
            List<string> shoppingList = new List<string>() { "Aparrel", "bangles", "groceries" };
            List<int> randomNumbers = new List<int>() { 111, 222, 333, 444, 555 };

            shoppingList.Add("fruits");
            randomNumbers.Add(999);

            shoppingList[0] = "Hair accessories";   //changing the value at position 0
            shoppingList.Remove("bangles");

            //Print the array, list values
            Console.WriteLine("Printing names array");
            foreach (var name in names)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("Printing shoppingList list");
            foreach (var item in shoppingList)
            {
                Console.WriteLine(item);
            }


        }

        private static void UsingSwitch()
        {

            switch (DateTime.Today.AddDays(4).DayOfWeek)
            {
                case DayOfWeek.Saturday:
                case DayOfWeek.Sunday:
                    Console.WriteLine("Wow.. the weekend! Enjoy!");
                    break;

                case DayOfWeek.Monday:
                    Console.WriteLine("First working day of the week");
                    break;

                case DayOfWeek.Tuesday:
                case DayOfWeek.Wednesday:
                case DayOfWeek.Thursday:
                case DayOfWeek.Friday:
                    Console.WriteLine("A normal weekday");
                    break;

                default:
                    Console.WriteLine("Today is Earth Day");
                    break;
            }
        }

        private static void TweakingTypes()
        {
            Int16 num1 = 100;
            Int64 num2 = 2093432;
            Int32 result = (Int32)num1 + (Int32)num2;

            object datafromuser = true;
            var decideType = true;

            //Fun with datatype formatters
            var fnum = 10f;
            double dnum = 1000d;
            decimal decNum = 2093.32m;

            DateTime today = DateTime.Today;
            string dow = DateTime.Today.DayOfWeek.ToString();
            Console.WriteLine($"Today's date: {today} | Day of week: {dow}");
            Console.WriteLine($"{today.AddDays(5).Date.ToShortDateString()}");
            Console.WriteLine($"{today.ToFileTime()}");

            //Print the datatypes of values using dataformatters
            Console.WriteLine($"Type of 10f: {10f.GetType().FullName}");
            Console.WriteLine($"Type of 10: {10.GetType().FullName}");
            Console.WriteLine($"Type of decideType: {decideType.GetType().FullName}");
            Console.WriteLine($"100 > 99? : {100 > 99}");

        }


        private static void UseConditions()
        {
            //take user input
            Console.WriteLine("How old are you?");
            string ageString = Console.ReadLine();
            //Convert the string to an integer
            Int32 age = Convert.ToInt32(ageString); //Type conversion: To convert two datatypes which have NO similarity
            Int16 age2 = (Int16)age;  //typecasting: The two types have some similarity. Hence implicit conversion is possible

            //Compare using conditions
            if (age <= 18)
            {
                Console.WriteLine("Still a kid. Not eligible");
            }
            else
            {
                Console.WriteLine("Eligibility test passed");
            }

        }


        private static void WorkingWithDatatypes()
        {
            int num1 = 100;
            int num2 = 200;
            int result = num1 + num2;
            Console.WriteLine($"{num1} + {num2}={result}");
            Console.WriteLine("{0} + {1}={2}", num1, num2, result);
        }



        //<private | public | protected | internal> <static> <return-type> <methodName>(<params>)
        private static void ReadWrite()
        {
            //Printing to command prompt (Console)
            //ClassName.StaticFunctionName()
            Console.WriteLine("Hello World!");

            string input = "";
            Console.WriteLine("Please enter your name: ");
            input = Console.ReadLine();
            Console.WriteLine("Welcome " + input);  //Old
            Console.WriteLine("Here is the key to your room, {0}", input);
            Console.WriteLine($"How are you doing {input}");    //C# 8
        }



    }
}
