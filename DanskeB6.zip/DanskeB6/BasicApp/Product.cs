﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicApp1
{
    //<[access-specifier]> <[static | sealed | abstract]> class <class-name> {}
    //Access-Specifier: Public | Private | Protected | Internal
    //static: Class cannot be instantiate
    //sealed: Cannot be modified (cannot be inherited, CAN BE Instantiated)
    //abstract: Incomplete class (can ONLY be inherited, CANNOT BE Instantiated)
    public class Product
    {
        public Product() { 
        
        }
        public Product(double cost)
        {
            this.Cost = cost;
            Random randomNum = new Random(1000);
            this.ProductId = randomNum.Next();
        }

        public Product(double cost, int productId)
        {
            this.Cost = cost;
            this.ProductId = productId;
        }

        //Thread-safety
        const string CONSTANT = "A Constant";
        readonly string READ_ONLY = "";
        private int _productId;   //A variable, technical term is class field
        public int ProductId
        {
            get { return _productId; }
            set { _productId = value; }
        }

        public string Name { get; set; }    //New C# update
        public double Cost { get; private set; }
        public string Prefix => "Danske";   //New C# update
        public string OldPrefix
        {
            get
            { 
                return "DN"; 
            }
        }
    }

    public class Store
    {
        public string Name { get; set; }    //property
        private List<Product> _productList = new List<Product>(); //field

        public bool AddProduct(Product objProduct)
        {
            if (objProduct != null)
            {
                objProduct.Name = "Changed HP";
                _productList.Add(objProduct);
                return true;
            }
            return false;
        }

        public List<Product> GetProducts()
        {
            return _productList;
        }
    }

    internal sealed class Account
    {

    }

    public static class Utilities
    {
        private static string privateValue { get; set; }
        public static string Value { get; set; }
        public static void Print(string message) {
            Utilities.privateValue = "I am private";
            Console.WriteLine(Utilities.privateValue);
            Console.WriteLine(message);
        }
    }

    public abstract class VendorAgreement
    {

    }


}
