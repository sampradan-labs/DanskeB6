﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicApp
{
   class Parent {
        public Parent(int aadhar)
        {
            this.Aadhar = aadhar;
        }

        public Parent(int aadhar, string name):this(aadhar)
        {
            this.Name = name;
        }

        public Parent(int aadhar, string name, int age) : this(aadhar,name)
        {

        }

        public int Aadhar { get; private set; }
        public string Name { get; private set; }
    }

    class Child{
        public string Name { get; set; }
        public Child(string name)
        {
            this.Name = name;
        }

        protected void SecretGift()
        {
            Console.WriteLine($"This is a secret gift for my dear grandhild {this.Name}");
        }
    }

    class GrandChild : Child {

        public GrandChild(string name):base(name)
        {

        }

        public void ShareParentGift()
        {
            this.SecretGift();
        }
    }

    /////////// Multi-level inheritance fun ///////////////
    ///
    class A {
        public string PropA => "Property in class A";
    }
    class B : A {
        public string PropB => "Property in class B";
    }
    class C : B {
        public string PropC => "Property in class C";
        public void AccessAll()
        {
            Console.WriteLine(this.PropA);
            Console.WriteLine(this.PropB);
            Console.WriteLine(this.PropC);
        }
    }

    ///Testing overloading///
    ///
    class OverLoadedClass
    {
        public void DoSomething() { Console.WriteLine("Done something"); }
        public void DoSomething(string task) { Console.WriteLine($"Done with {task}"); }
        public void DoSomething(bool submitReport, string task = "task A") { Console.WriteLine($"Done with {task}, status: {submitReport}"); }
        public void DoSomething(string task, int val, bool? done) { Console.WriteLine($"Done with {task}, status: {done}"); }

        public void DoSomething(string task, string subtask = "sub") { Console.WriteLine($"Done with {task}, status: {subtask}"); }
    }
}
